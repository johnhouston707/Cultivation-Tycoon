import React, { useEffect, useMemo, useRef, useState } from "react";

const TICK_MS = 2000;
const GRID_W = 10;
const GRID_H = 6;
const TILE_W = 96;
const TILE_H = 64;

const TILE_TYPES = {
  EMPTY: "empty",
  NURSERY: "nursery",
  VEG: "veg",
  FLOWER: "flower",
  DRY: "dry",
  CURE: "cure",
  UTIL: "utility",
  OFFICE: "office",
  STORAGE: "storage",
} as const;

const TILE_LABEL: Record<string, string> = {
  [TILE_TYPES.EMPTY]: "Empty",
  [TILE_TYPES.NURSERY]: "Nursery",
  [TILE_TYPES.VEG]: "Vegetative",
  [TILE_TYPES.FLOWER]: "Flower",
  [TILE_TYPES.DRY]: "Dry",
  [TILE_TYPES.CURE]: "Cure",
  [TILE_TYPES.UTIL]: "Utility",
  [TILE_TYPES.OFFICE]: "Office",
  [TILE_TYPES.STORAGE]: "Storage",
};

const BUILD_COST: Record<string, number> = {
  [TILE_TYPES.NURSERY]: 5000,
  [TILE_TYPES.VEG]: 7000,
  [TILE_TYPES.FLOWER]: 12000,
  [TILE_TYPES.DRY]: 4000,
  [TILE_TYPES.CURE]: 4000,
  [TILE_TYPES.UTIL]: 3000,
  [TILE_TYPES.OFFICE]: 3000,
  [TILE_TYPES.STORAGE]: 2000,
};

const UPKEEP: Record<string, number> = {
  [TILE_TYPES.NURSERY]: 60,
  [TILE_TYPES.VEG]: 90,
  [TILE_TYPES.FLOWER]: 160,
  [TILE_TYPES.DRY]: 30,
  [TILE_TYPES.CURE]: 30,
  [TILE_TYPES.UTIL]: 25,
  [TILE_TYPES.OFFICE]: 25,
  [TILE_TYPES.STORAGE]: 10,
  [TILE_TYPES.EMPTY]: 0,
};

const ROLES = [
  { id: "mgr", name: "Manager", salaryPerDay: 220, effect: { compliance: 0.5 } },
  { id: "tech", name: "Cultivation Tech", salaryPerDay: 140, effect: { quality: 0.4 } },
  { id: "ops", name: "Ops/Facilities", salaryPerDay: 120, effect: { downtime: -0.4 } },
  { id: "sales", name: "Sales", salaryPerDay: 150, effect: { demand: 0.4 } },
] as const;

const STRAINS = [
  { id: "alpha", name: "Alpha OG", yield: 1.0, demand: 1.0, cycleDays: 56, pricePerUnit: 12 },
  { id: "beta", name: "Beta Dream", yield: 0.9, demand: 1.3, cycleDays: 63, pricePerUnit: 13 },
  { id: "gamma", name: "Gamma Glue", yield: 1.2, demand: 0.9, cycleDays: 70, pricePerUnit: 11 },
  { id: "delta", name: "Delta Punch", yield: 1.1, demand: 1.1, cycleDays: 63, pricePerUnit: 12 },
];

type TileType = keyof typeof TILE_TYPES | string;
interface Tile { type: TileType }
interface StaffMember { id: string; role: string; name: string }
interface Batch { id: string; strainId: string; daysInCycle: number }
interface Inventory { units: number; avgQuality: number }
interface Metrics { powerCapacity: number; biosecurity: number }

interface GameState {
  day: number;
  cash: number;
  reputation: number;
  compliance: number;
  traceability: number;
  marketDemand: number;
  selectedTileType: string;
  grid: Tile[];
  staff: StaffMember[];
  batches: Batch[];
  inventory: Inventory;
  paused: boolean;
  downtimeDays: number;
  metrics: Metrics;
  messages: string[];
}

const defaultGrid = (): Tile[] => Array.from({ length: GRID_W * GRID_H }, () => ({ type: TILE_TYPES.EMPTY }));

const initialState = (): GameState => ({
  day: 1,
  cash: 100000,
  reputation: 50,
  compliance: 60,
  traceability: 60,
  marketDemand: 100,
  selectedTileType: TILE_TYPES.NURSERY,
  grid: defaultGrid(),
  staff: [],
  batches: [],
  inventory: { units: 0, avgQuality: 70 },
  paused: true,
  downtimeDays: 0,
  metrics: { powerCapacity: 0.4, biosecurity: 0.5 },
  messages: ["Welcome to Cultivation Tycoon (Isometric)! Build rooms, hire staff, and ship product."],
});

const fmt = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });

const saveGame = (state: GameState) => localStorage.setItem("cultivation_tycoon_save", JSON.stringify(state));
const loadGame = (): GameState | null => { const raw = localStorage.getItem("cultivation_tycoon_save"); if (!raw) return null; try { return JSON.parse(raw); } catch { return null; } };
const clearSave = () => localStorage.removeItem("cultivation_tycoon_save");

function canPlace(type: string, cash: number) { if (type === TILE_TYPES.EMPTY) return true; return cash >= (BUILD_COST[type] ?? 0); }
function calcDailyUpkeep(grid: Tile[], staff: StaffMember[]) {
  const rooms = grid.reduce((sum, t) => sum + (UPKEEP[t.type] ?? 0), 0);
  const salaries = staff.reduce((sum, s) => sum + (ROLES.find(r => r.id === s.role)?.salaryPerDay ?? 0), 0);
  return rooms + salaries;
}
function facilityCapacity(grid: Tile[]) {
  const counts = grid.reduce<Record<string, number>>((m, t) => { m[t.type] = (m[t.type] ?? 0) + 1; return m; }, {});
  return { nurserySlots: (counts[TILE_TYPES.NURSERY] ?? 0) * 50, vegSlots: (counts[TILE_TYPES.VEG] ?? 0) * 40, flowerSlots: (counts[TILE_TYPES.FLOWER] ?? 0) * 30, drySlots: (counts[TILE_TYPES.DRY] ?? 0) * 60, cureSlots: (counts[TILE_TYPES.CURE] ?? 0) * 60 };
}
function staffEffects(staff: StaffMember[]) {
  const e = { compliance: 0, quality: 0, downtime: 0, demand: 0 };
  staff.forEach(s => { const r = ROLES.find(r => r.id === s.role); if (!r) return; Object.entries(r.effect).forEach(([k,v]) => (e as any)[k] += v as number); });
  return e;
}
function randomEvent(state: GameState) {
  if (Math.random() > 0.15) return state;
  const events = [
    { label: "Regulatory Inspection", apply: (s: GameState) => {
      const pass = s.compliance >= 70 && s.traceability >= 70;
      const fee = pass ? 0 : 2500; const delta = pass ? 5 : -10;
      return { next: { ...s, cash: s.cash - fee, reputation: Math.min(100, Math.max(0, s.reputation + delta)) }, log: pass ? "Inspection passed. Reputation up." : "Issues found; fine paid, reputation hit." };
    }},
    { label: "Power Spike", apply: (s: GameState) => {
      const mitigated = s.metrics.powerCapacity >= 0.9;
      const loss = mitigated ? 0 : Math.floor(s.inventory.units * 0.05);
      const inv = Math.max(0, s.inventory.units - loss);
      return { next: { ...s, inventory: { ...s.inventory, units: inv }, downtimeDays: s.downtimeDays + (mitigated ? 0 : 2) }, log: mitigated ? "Handled by utility upgrades." : `Waste ${loss} units + 2 days downtime.` };
    }},
    { label: "Market Shift", apply: (s: GameState) => {
      const delta = (Math.random() < 0.5 ? -1 : 1) * (5 + Math.random() * 10);
      const md = Math.max(60, Math.min(140, s.marketDemand + delta));
      return { next: { ...s, marketDemand: md }, log: delta > 0 ? "Regional demand up!" : "Regional demand down." };
    }},
  ];
  const ev = events[Math.floor(Math.random() * events.length)];
  const { next, log } = ev.apply(state);
  return { ...next, messages: [`${ev.label}: ${log}`, ...state.messages].slice(0, 8) };
}
function endOfDay(state: GameState): GameState {
  let next = { ...state };
  if (next.downtimeDays > 0) { next.downtimeDays -= 1; next.messages = ["Recovering from downtime.", ...next.messages].slice(0, 8); }
  const upkeep = calcDailyUpkeep(next.grid, next.staff); next.cash -= upkeep;
  const eff = staffEffects(next.staff);
  next.compliance = Math.max(0, Math.min(100, next.compliance + eff.compliance - 0.1));
  next.traceability = Math.max(0, Math.min(100, next.traceability + 0.2 - 0.05));
  const { flowerSlots } = facilityCapacity(next.grid);
  let completedUnits = 0;
  if (next.downtimeDays <= 0) {
    next.batches = next.batches.map(b => ({ ...b, daysInCycle: b.daysInCycle + 1 }));
    const done: Batch[] = [];
    next.batches.forEach(b => { const s = STRAINS.find(x => x.id === b.strainId)!; if (b.daysInCycle >= s.cycleDays) done.push(b); });
    if (done.length) {
      done.forEach(b => {
        const s = STRAINS.find(x => x.id === b.strainId)!;
        const quality = Math.max(50, Math.min(100, state.inventory.avgQuality + eff.quality * 10));
        const units = Math.floor(s.yield * 100);
        next.inventory.units += units;
        next.inventory.avgQuality = Math.round((next.inventory.avgQuality * 0.7 + quality * 0.3));
        completedUnits += units;
      });
      next.batches = next.batches.filter(b => !done.includes(b));
      next.messages = [`Harvest: +${completedUnits} units`, ...next.messages].slice(0, 8);
    }
  }
  const activeFlower = next.batches.length;
  if (activeFlower > flowerSlots) {
    const overflow = activeFlower - flowerSlots; const loss = Math.floor(overflow * 20);
    next.inventory.units = Math.max(0, next.inventory.units - loss);
    next.messages = [`Overcapacity loss: -${loss} units`, ...next.messages].slice(0, 8);
  }
  const demandIndex = Math.max(0.6, Math.min(1.4, next.marketDemand / 100 + eff.demand * 0.2));
  const baseUnitsSold = Math.floor(30 * demandIndex * (0.5 + next.reputation / 200));
  const unitsSold = Math.min(next.inventory.units, baseUnitsSold);
  if (unitsSold > 0) {
    const avgPrice = STRAINS.reduce((sum, s) => sum + s.pricePerUnit, 0) / STRAINS.length;
    const price = Math.round(avgPrice * (0.9 + next.inventory.avgQuality / 500));
    const revenue = unitsSold * price;
    next.cash += revenue;
    next.inventory.units -= unitsSold;
    next.reputation = Math.min(100, next.reputation + 0.2);
    next.messages = [`Sold ${unitsSold} units @ $${price} = $${revenue}`, ...next.messages].slice(0, 8);
  }
  next = randomEvent(next);
  if (next.cash < -5000) { next.paused = true; next.messages = ["⚠️ Insolvency risk. Pause triggered.", ...next.messages].slice(0, 8); }
  next.day += 1; return next;
}
const ASSET: Record<string, string> = {
  [TILE_TYPES.NURSERY]: "/assets/nursery.png",
  [TILE_TYPES.VEG]: "/assets/veg.png",
  [TILE_TYPES.FLOWER]: "/assets/flower.png",
  [TILE_TYPES.DRY]: "/assets/dry.png",
  [TILE_TYPES.CURE]: "/assets/cure.png",
  [TILE_TYPES.UTIL]: "/assets/utility.png",
  [TILE_TYPES.OFFICE]: "/assets/office.png",
  [TILE_TYPES.STORAGE]: "/assets/storage.png",
  [TILE_TYPES.EMPTY]: "/assets/empty.png",
};
function isoPosition(ix: number, iy: number) {
  const x = ix * TILE_W; const y = iy * TILE_H;
  const isoX = (x - y) / 2; const isoY = (x + y) / 4; return { isoX, isoY };
}
function Stat({ label, value, sub }: { label: string; value: React.ReactNode; sub?: React.ReactNode }) {
  return (<div className="rounded-2xl bg-white p-3 shadow-sm"><div className="text-xs uppercase tracking-wide text-zinc-500">{label}</div><div className="text-xl font-semibold">{value}</div>{sub && <div className="text-xs text-zinc-500">{sub}</div>}</div>);
}
function Toolbar({ selected, onSelect }: { selected: string; onSelect: (t: string) => void }) {
  const items = Object.values(TILE_TYPES).filter(t => t !== TILE_TYPES.EMPTY);
  return (<div className="flex flex-wrap gap-2">{items.map(t => (<button key={t} onClick={() => onSelect(t)} className={`px-3 py-2 rounded-xl border text-sm ${selected===t?"bg-zinc-900 text-white border-zinc-900":"bg-white border-zinc-300"}`}>{TILE_LABEL[t]}<span className="ml-2 text-xs opacity-70">{BUILD_COST[t]? new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(BUILD_COST[t]):""}</span></button>))}</div>);
}
function StaffPane({ staff, onHire, onFire }: { staff: StaffMember[]; onHire: (roleId: string) => void; onFire: (id: string) => void; }) {
  return (<div className="space-y-3"><div className="text-sm font-medium">Staff</div><div className="grid grid-cols-2 gap-2">{ROLES.map(r => (<button key={r.id} onClick={() => onHire(r.id)} className="rounded-xl border p-2 bg-white hover:bg-zinc-50"><div className="font-semibold">Hire {r.name}</div><div className="text-xs text-zinc-500">Salary ${r.salaryPerDay}/day</div></button>))}</div><div className="rounded-2xl border bg-white divide-y">{staff.length === 0 && <div className="p-3 text-sm text-zinc-500">No staff yet.</div>}{staff.map(s => { const r = ROLES.find(x => x.id === s.role)!; return (<div key={s.id} className="p-3 flex items-center justify-between"><div><div className="font-medium">{s.name}</div><div className="text-xs text-zinc-500">{r.name} • ${r.salaryPerDay}/day</div></div><button onClick={() => onFire(s.id)} className="text-red-600 text-sm">Fire</button></div>); })}</div></div>);
}
function BatchesPane({ batches, onStartBatch }: { batches: Batch[]; onStartBatch: (strainId: string) => void; }) {
  return (<div className="space-y-3"><div className="text-sm font-medium">Production</div><div className="grid grid-cols-2 gap-2">{STRAINS.map(s => (<button key={s.id} onClick={() => onStartBatch(s.id)} className="rounded-xl border p-2 bg-white hover:bg-zinc-50"><div className="font-semibold">Start {s.name}</div><div className="text-xs text-zinc-500">Cycle {s.cycleDays}d • Yield {Math.round(s.yield*100)}u • Base ${s.pricePerUnit}</div></button>))}</div><div className="rounded-2xl border bg-white divide-y">{batches.length === 0 && <div className="p-3 text-sm text-zinc-500">No active batches.</div>}{batches.map(b => { const s = STRAINS.find(x => x.id === b.strainId)!; const pct = Math.min(100, Math.round((b.daysInCycle / s.cycleDays) * 100)); return (<div key={b.id} className="p-3"><div className="flex items-center justify-between text-sm"><div className="font-medium">{s.name}</div><div className="text-xs text-zinc-500">{b.daysInCycle}/{s.cycleDays}d</div></div><div className="w-full bg-zinc-200 h-2 rounded-full mt-2"><div className="h-2 bg-zinc-900 rounded-full" style={{ width: pct + "%" }} /></div></div>); })}</div></div>);
}
export default function App() {
  const [state, setState] = useState<GameState>(() => loadGame() || initialState());
  const tickRef = useRef<number | null>(null);
  useEffect(() => { if (state.paused) { if (tickRef.current) { clearInterval(tickRef.current); tickRef.current = null; } return; } tickRef.current = window.setInterval(() => setState(prev => endOfDay(prev)), TICK_MS); return () => { if (tickRef.current) clearInterval(tickRef.current); }; }, [state.paused]);
  useEffect(() => { saveGame(state); }, [state]);
  const dailyUpkeep = useMemo(() => calcDailyUpkeep(state.grid, state.staff), [state.grid, state.staff]);
  const onSelectTileType = (t: string) => setState(s => ({ ...s, selectedTileType: t }));
  const onPlace = (idx: number) => setState(s => { const type = s.selectedTileType; if (!canPlace(type, s.cash)) return s; const next = { ...s }; const grid = [...next.grid]; const cost = BUILD_COST[type] ?? 0; grid[idx] = { type }; next.grid = grid; next.cash -= cost; next.messages = [`${TILE_LABEL[type]} built for ${fmt.format(cost)}`, ...next.messages].slice(0, 8); if (type === TILE_TYPES.UTIL) next.metrics.powerCapacity = Math.min(1, next.metrics.powerCapacity + 0.15); if (type === TILE_TYPES.STORAGE) next.metrics.biosecurity = Math.min(1, next.metrics.biosecurity + 0.1); return next; });
  const onHire = (roleId: string) => setState(s => { const role = ROLES.find(r => r.id === roleId)!; if (s.cash < role.salaryPerDay * 14) { return { ...s, messages: ["Not enough runway for salary (need ~14 days)", ...s.messages].slice(0,8) }; } const id = Math.random().toString(36).slice(2, 9); const name = role.name + " " + id.toUpperCase(); return { ...s, staff: [...s.staff, { id, role: role.id, name }], messages: ["Hired " + role.name, ...s.messages].slice(0,8) }; });
  const onFire = (id: string) => setState(s => ({ ...s, staff: s.staff.filter(p => p.id !== id), messages: ["Staff member let go.", ...s.messages].slice(0,8) }));
  const onStartBatch = (strainId: string) => setState(s => { const { flowerSlots } = facilityCapacity(s.grid); if (s.batches.length >= flowerSlots) return { ...s, messages: ["Flower rooms at capacity.", ...s.messages].slice(0,8) }; const id = Math.random().toString(36).slice(2,9); return { ...s, batches: [...s.batches, { id, strainId, daysInCycle: 0 }], messages: ["Started batch: " + STRAINS.find(x => x.id===strainId)!.name, ...s.messages].slice(0,8) }; });
  const resetGame = () => { clearSave(); setState(initialState()); };
  const tiles = []; for (let y = 0; y < GRID_H; y++) { for (let x = 0; x < GRID_W; x++) { const idx = y*GRID_W + x; const { isoX, isoY } = isoPosition(x, y); tiles.push({ x, y, idx, isoX, isoY }); } }
  return (<div className="min-h-screen bg-zinc-100 text-zinc-900 p-4 md:p-6"><div className="mx-auto max-w-7xl grid grid-cols-1 lg:grid-cols-12 gap-4"><header className="lg:col-span-12 flex flex-wrap items-center justify-between gap-3"><h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">🌿 Cultivation Tycoon — Isometric</h1><div className="flex items-center gap-2"><button onClick={() => setState(s => ({ ...s, paused: !s.paused }))} className="px-3 py-2 rounded-xl bg-zinc-900 text-white text-sm">{state.paused ? "Start" : "Pause"}</button><button onClick={resetGame} className="px-3 py-2 rounded-xl border text-sm">New Game</button></div></header><section className="lg:col-span-9 space-y-3"><div className="rounded-2xl border bg-white p-3"><div className="mb-2 text-sm text-zinc-600">Build Rooms</div><Toolbar selected={state.selectedTileType} onSelect={onSelectTileType} /></div><div className="iso-stage" style={{ ["--tile-w" as any]: f"{TILE_W}px", ["--tile-h" as any]: f"{TILE_H}px" }}><div className="iso-grid">{tiles.map(t => { const tile = state.grid[t.idx]; const src = ASSET[tile.type] || ASSET[TILE_TYPES.EMPTY]; const style: React.CSSProperties = { left: `calc(${t.isoX}px)`, top: `calc(${t.isoY}px)`, ["--tx" as any]: "0px", ["--ty" as any]: "0px", ["--tile-w" as any]: `${TILE_W}px`, ["--tile-h" as any]: `${TILE_H}px`, }; return (<div key={t.idx} className="iso-tile" style={style} onClick={() => onPlace(t.idx)}><img src={src} alt={TILE_LABEL[tile.type]} width={TILE_W} height={TILE_H} draggable={false} /><div className="iso-label">{TILE_LABEL[tile.type]}</div></div>); })}</div></div></section><aside className="lg:col-span-3 space-y-3"><div className="rounded-2xl border bg-white p-3"><div className="grid grid-cols-2 gap-3"><Stat label="Day" value={state.day} /><Stat label="Cash" value={fmt.format(state.cash)} sub={`Upkeep ${fmt.format(dailyUpkeep)}/day`} /><Stat label="Inventory" value={`${state.inventory.units} units`} sub={`Quality ${state.inventory.avgQuality}`} /><Stat label="Reputation" value={`${Math.round(state.reputation)}/100`} /><Stat label="Compliance" value={`${Math.round(state.compliance)}/100`} /><Stat label="Traceability" value={`${Math.round(state.traceability)}/100`} /><Stat label="Demand" value={`${Math.round(state.marketDemand)}`} sub="60–140 index" /><Stat label="Downtime" value={`${state.downtimeDays}d`} /></div></div><div className="rounded-2xl border bg-white p-3"><BatchesPane batches={state.batches} onStartBatch={onStartBatch} /></div><div className="rounded-2xl border bg-white p-3"><StaffPane staff={state.staff} onHire={onHire} onFire={onFire} /></div><div className="rounded-2xl border bg-white p-3"><div className="text-sm font-medium mb-2">Messages</div><ul className="space-y-1 max-h-48 overflow-auto pr-1">{state.messages.map((m, idx) => (<li key={idx} className="text-sm text-zinc-700">• {m}</li>))}</ul></div><div className="rounded-2xl border bg-white p-3"><div className="text-sm font-medium mb-2">Save/Load</div><div className="flex gap-2"><button onClick={() => saveGame(state)} className="px-3 py-2 rounded-xl border text-sm">Save</button><button onClick={() => { const s = loadGame(); if (s) setState(s); }} className="px-3 py-2 rounded-xl border text-sm">Load</button><button onClick={resetGame} className="px-3 py-2 rounded-xl border text-sm">Clear</button></div></div></aside></div><div className="max-w-7xl mx-auto mt-4 text-xs text-zinc-500">Tip: Utility rooms improve power resilience. Hire Manager for compliance, Tech for quality, Sales for demand.</div></div>);
}
